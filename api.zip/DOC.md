# Historial
http://dts.location-world.com/api/Fleet/dailyhistory?token=01EC469EB5F64D8DA878042400D3CBA2&imei=867162025540683&year=2018&month=06&day=16&timezoneoffset=-5&culture=es

# Odómetro
http://dts.location-world.com/api/Fleet/odometers?token=01EC469EB5F64D8DA878042400D3CBA2&time_zone_offset=-5

# informacion
http://dts.location-world.com/api/fleet/onlinedevicesinfo?token=01EC469EB5F64D8DA878042400D3CBA2&time_zone_offset=-5&culture=es

TOKEN: 01EC469EB5F64D8DA878042400D3CBA2


# wikis

https://wikifleet.carsync.com/dts

acceso a aplicacion web

USUARIO: dsanchez@icsse.com

* CONTRASEÑA: logcourier18

 USUARIO: jfgonzalez@valdez.com.ec

* CONTRASEÑA: valdez2018